
#ifndef UTILS_H
#define UTILS_H

#include <stdint.h>

uint16_t utils_crc16(const uint8_t *data, uint16_t length);

#endif
