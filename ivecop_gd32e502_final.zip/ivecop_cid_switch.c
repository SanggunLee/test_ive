
#include "ivecop.h"
#include <stdio.h>

void cid_handle_response(const ivecop_frame_t* frame);
void cid_handle_comm_error(const ivecop_frame_t* frame);
void cid_handle_mute_zone(const ivecop_frame_t* frame);
void cid_handle_mute_channels(const ivecop_frame_t* frame);
void cid_handle_volume_zone(const ivecop_frame_t* frame);
void cid_handle_eq_common(const ivecop_frame_t* frame);
void cid_handle_sensor_voltage(const ivecop_frame_t* frame);
void cid_handle_module_enable(const ivecop_frame_t* frame);

void ivecop_handle_cid(const ivecop_frame_t* frame) {
    if (!frame) return;

    switch (frame->cid) {
        case 0x01: cid_handle_response(frame); break;
        case 0x02: cid_handle_comm_error(frame); break;
        case 0x21: cid_handle_mute_zone(frame); break;
        case 0x23: cid_handle_mute_channels(frame); break;
        case 0x31: cid_handle_volume_zone(frame); break;
        case 0x33:
        case 0x34:
        case 0x35:
        case 0x36:
        case 0x37:
            cid_handle_eq_common(frame); break;
        case 0xA0: cid_handle_sensor_voltage(frame); break;
        case 0xB0: cid_handle_module_enable(frame); break;
        default:
            printf("[CID 0x%02X] Unknown or unhandled CID received.\n", frame->cid);
            break;
    }
}
