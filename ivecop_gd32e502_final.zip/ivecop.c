
#include "ivecop.h"
#include "a2b.h"
#include "utils.h"
#include <string.h>

static ivecop_state_t state = IVECOP_STATE_INIT;

void ivecop_init(void) {
    state = IVECOP_STATE_DISCOVERY;
}

void ivecop_process(void) {
    ivecop_frame_t frame;

    switch (state) {
        case IVECOP_STATE_DISCOVERY:
            if (a2b_discover_nodes()) {
                state = IVECOP_STATE_RUNNING;
            } else {
                state = IVECOP_STATE_ERROR;
            }
            break;

        case IVECOP_STATE_RUNNING:
            if (a2b_receive_frame(&frame)) {
                ivecop_handle_cid(&frame);
            }
            break;

        case IVECOP_STATE_ERROR:
            a2b_reset();
            state = IVECOP_STATE_DISCOVERY;
            break;

        default:
            state = IVECOP_STATE_ERROR;
            break;
    }
}
