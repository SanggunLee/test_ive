
#include "ivecop.h"
#include <stdio.h>

/* CID 0x01 - Response Command */
void cid_handle_response(const ivecop_frame_t* frame) {
    if (frame->data_size >= 3) {
        cid_response_t* rsp = (cid_response_t*)frame->data;
        printf("[CID 0x01] Response: echo=0x%02X status=%d data=0x%02X\n",
               rsp->cid_echo, rsp->status, rsp->data);
    }
}

/* CID 0x02 - Communication Error */
void cid_handle_comm_error(const ivecop_frame_t* frame) {
    ivecop_error_t err = (ivecop_error_t)frame->data[0];
    printf("[CID 0x02] Communication Error: Type %d\n", err);
}

/* CID 0x21 - Mute Zone */
void cid_handle_mute_zone(const ivecop_frame_t* frame) {
    if (frame->data_size >= 2) {
        cid_mute_zone_t* mute = (cid_mute_zone_t*)frame->data;
        printf("[CID 0x21] Mute Zone: zone=%d, command=%d\n", mute->zone, mute->command);
        // TODO: 실제 Mute 제어 로직 추가
    }
}

/* CID 0x23 - Mute Channels */
void cid_handle_mute_channels(const ivecop_frame_t* frame) {
    if (frame->data_size >= 2) {
        cid_mute_channel_t* mchan = (cid_mute_channel_t*)frame->data;
        printf("[CID 0x23] Mute Channels: bitmap=0x%04X\n", mchan->mute_bitmap);
    }
}

/* CID 0x31 - Volume Zone */
void cid_handle_volume_zone(const ivecop_frame_t* frame) {
    if (frame->data_size >= 2) {
        cid_equalizer_t* vol = (cid_equalizer_t*)frame->data;
        printf("[CID 0x31] Volume Zone: zone=%d, volume=%d%%\n", vol->zone, vol->value);
    }
}

/* CID 0x33~0x37 - Equalizer Related */
void cid_handle_eq_common(const ivecop_frame_t* frame) {
    if (frame->data_size >= 2) {
        cid_equalizer_t* eq = (cid_equalizer_t*)frame->data;
        printf("[CID 0x%02X] EQ Control: zone=%d, value=%d\n", frame->cid, eq->zone, eq->value);
    }
}

/* CID 0xA0 - Sensor Voltage */
void cid_handle_sensor_voltage(const ivecop_frame_t* frame) {
    if (frame->data_size >= 2) {
        cid_sensor_value_t* sensor = (cid_sensor_value_t*)frame->data;
        printf("[CID 0xA0] Sensor Voltage: %d mV\n", sensor->sense_value_mv);
    }
}

/* CID 0xB0 - Module Enable */
void cid_handle_module_enable(const ivecop_frame_t* frame) {
    printf("[CID 0xB0] Module Enable Command received.\n");
}
