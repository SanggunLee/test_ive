
#ifndef IVECOP_H
#define IVECOP_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_DATA_SIZE 30

typedef enum {
    IVECOP_STATE_INIT,
    IVECOP_STATE_DISCOVERY,
    IVECOP_STATE_RUNNING,
    IVECOP_STATE_ERROR
} ivecop_state_t;

typedef struct {
    uint8_t frame_type;
    uint8_t data_size;
    uint8_t cid;
    uint8_t data[MAX_DATA_SIZE];
} ivecop_frame_t;

void ivecop_init(void);
void ivecop_process(void);
void ivecop_handle_cid(const ivecop_frame_t* frame);

#endif
