
#ifndef PERIPHERALS_H
#define PERIPHERALS_H

void peripherals_init(void);
void peripherals_process(void);

#endif
