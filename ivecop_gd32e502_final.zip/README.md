
# IVECOP Protocol for GD32E502 (Full + CID Handlers)

Includes:
- main loop with protocol
- A2B interface
- IVECOP state machine
- CID handlers for common commands
