
#include "a2b.h"
#include <stdio.h>
#include <string.h>

void a2b_init(void) {
    printf("[A2B] Initialized\n");
}

bool a2b_discover_nodes(void) {
    printf("[A2B] Discovery success\n");
    return true;
}

void a2b_reset(void) {
    printf("[A2B] Reset triggered\n");
}

bool a2b_receive_frame(ivecop_frame_t *frame) {
    return false;
}

bool a2b_send_frame(uint8_t node_addr, const ivecop_frame_t *frame) {
    printf("[A2B] Send: node %d, cid 0x%02X\n", node_addr, frame->cid);
    return true;
}
