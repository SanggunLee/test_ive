
#include "peripherals.h"
#include <stdio.h>

void peripherals_init(void) {
    printf("[PERIPHERAL] Initialized\n");
}

void peripherals_process(void) {
    // Simulated
}
