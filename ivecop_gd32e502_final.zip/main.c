
#include "ivecop.h"
#include "a2b.h"
#include "peripherals.h"

int main(void) {
    systick_config();
    board_initialize();

    a2b_init();
    ivecop_init();
    peripherals_init();

    while (1) {
        ivecop_process();
        peripherals_process();
    }
    return 0;
}
