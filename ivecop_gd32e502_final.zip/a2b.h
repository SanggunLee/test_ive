
#ifndef A2B_H
#define A2B_H

#include <stdbool.h>
#include <stdint.h>
#include "ivecop.h"

void a2b_init(void);
bool a2b_discover_nodes(void);
void a2b_reset(void);
bool a2b_receive_frame(ivecop_frame_t *frame);
bool a2b_send_frame(uint8_t node_addr, const ivecop_frame_t *frame);

#endif
