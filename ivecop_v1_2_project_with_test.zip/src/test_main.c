#include <stdio.h>
#include "a2b_mailbox.h"
#include "crc_utils.h"
#include "buffer_utils.h"
#include "timer_utils.h"

// 전역 시스템 타이머 (밀리초)
volatile uint32_t system_tick_ms = 0;

// 테스트용 가짜 SPI 프레임 송수신 함수
void fake_tick_advance(uint32_t ms) {
    system_tick_ms += ms;
}

void test_crc() {
    uint8_t data[] = {0x01, 0x02, 0x03};
    uint16_t crc = calculate_crc16(data, sizeof(data));
    printf("CRC test: 0x%04X\n", crc);
}

void test_buffer_copy() {
    uint8_t src[3] = {1, 2, 3};
    uint8_t dst[64] = {0};
    if (safe_buffer_copy(dst, src, 3)) {
        printf("Buffer copy test: OK\n");
    } else {
        printf("Buffer copy test: FAIL\n");
    }
}

void test_timer() {
    timer_start(50);
    fake_tick_advance(30);
    printf("Timer expired (30ms)? %s\n", timer_expired() ? "YES" : "NO");
    fake_tick_advance(30);
    printf("Timer expired (60ms)? %s\n", timer_expired() ? "YES" : "NO");
}

void test_mailbox_tx() {
    uint8_t test_data[] = {0x20, 0x01};  // CID 0x20, DATA 0x01
    printf("Sending Mailbox Frame...\n");
    a2b_write_mailbox(0x01, test_data, sizeof(test_data));
}

int main(void) {
    printf("=== IVECOP Test Start ===\n");
    test_crc();
    test_buffer_copy();
    test_timer();
    test_mailbox_tx();
    printf("=== IVECOP Test End ===\n");
    return 0;
}
