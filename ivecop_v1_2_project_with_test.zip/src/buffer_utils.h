#ifndef BUFFER_UTILS_H
#define BUFFER_UTILS_H

#include <stdint.h>

#define MAX_BUFFER_SIZE 64

uint8_t safe_buffer_copy(uint8_t* dst, const uint8_t* src, uint8_t length);

#endif // BUFFER_UTILS_H
