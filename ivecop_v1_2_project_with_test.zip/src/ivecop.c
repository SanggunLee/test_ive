#include "ivecop.h"
#include "a2b.h"
#include <stdint.h>
#include <string.h>

// IVECOP 상태 정의
typedef enum {
    STATE_DISCOVERY,
    STATE_RUNNING,
    STATE_ERROR
} ivecop_state_t;

static ivecop_state_t current_state;

void ivecop_init(void) {
    current_state = STATE_DISCOVERY;
}

void ivecop_process(void) {
    switch (current_state) {
        case STATE_DISCOVERY:
            if (a2b_discover_nodes()) {
                current_state = STATE_RUNNING;
            } else {
                current_state = STATE_ERROR;
            }
            break;
        case STATE_RUNNING:
            ivecop_handle_messages();
            break;
        case STATE_ERROR:
            a2b_reset();
            break;
    }
}

void ivecop_handle_messages(void) {
    uint8_t frame[4];
    if (a2b_receive_frame(frame)) {
        uint8_t cid = frame[1];
        // CID 처리 로직 (예시로 echo)
        uint8_t response[3] = {cid, 0x00, frame[2]};
        ivecop_send_command(0x01, 0x01, response, 3); // CID 01h 응답
    }
}

void ivecop_send_command(uint8_t uid, uint8_t cid, const uint8_t* data, uint8_t data_len) {
    uint8_t frame[4];
    frame[0] = (0 << 7) | (data_len & 0x7F);  // FRAME_TYPE = 0 (Single Frame)
    frame[1] = cid;
    frame[2] = data_len > 0 ? data[0] : 0;
    frame[3] = data_len > 1 ? data[1] : 0;
    a2b_send_frame(uid, frame);
}
