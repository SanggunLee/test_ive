#include "buffer_utils.h"
#include <string.h>

// 안전한 버퍼 복사: 오버플로우 방지
uint8_t safe_buffer_copy(uint8_t* dst, const uint8_t* src, uint8_t length) {
    if (length > MAX_BUFFER_SIZE)
        return 0;
    memcpy(dst, src, length);
    return 1;
}
