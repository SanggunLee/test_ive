#include "timer_utils.h"

// 타이머 변수 (가상 예시)
static volatile uint32_t start_tick = 0;
extern volatile uint32_t system_tick_ms; // systick interrupt로 증가해야 함

void timer_start(uint16_t ms) {
    start_tick = system_tick_ms + ms;
}

uint8_t timer_expired(void) {
    return (system_tick_ms >= start_tick);
}
