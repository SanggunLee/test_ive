#include "ivecop.h"
#include "a2b.h"
#include "peripherals.h"

int main(void) {
    systick_config();              // 시스템 타이머 설정
    ivecop_init();                 // IVECOP 상태 초기화
    peripherals_init();           // 센서 및 주변장치 초기화
    a2b_init();                    // A2B 네트워크 초기화

    while (1) {
        ivecop_process();         // IVECOP 상태 처리
        peripherals_process();    // 센서 값 등 처리
    }
}
