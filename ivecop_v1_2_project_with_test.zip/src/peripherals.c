#include "peripherals.h"

void peripherals_init(void) {
    // 온도센서, DAC, ADC 등 초기화
}

void peripherals_process(void) {
    // 주기적으로 센서값 읽기 등 수행
}
