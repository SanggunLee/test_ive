#include "a2b_mailbox.h"
#include "a2b.h"
#include <string.h>

// Mailbox 프레임 타입 정의
#define FRAME_TYPE_START 0x00
#define FRAME_TYPE_CONT  0x80

void a2b_write_mailbox(uint8_t node_addr, const uint8_t* data, uint8_t length) {
    if (length <= 2) {
        // Single Frame (1 Start Frame)
        uint8_t frame[4] = {
            (FRAME_TYPE_START | (length & 0x7F)),  // FRAME_TYPE=0, DATA_SIZE
            data[0],                               // CID
            (length > 1 ? data[1] : 0),             // DATA_0
            (length > 2 ? data[2] : 0)              // DATA_1
        };
        a2b_send_frame(node_addr, frame);
    } else {
        // Multi Frame (Start + n Continuation)
        uint8_t start_frame[4] = {
            (FRAME_TYPE_START | (length & 0x7F)),
            data[0],  // CID
            data[1],  // DATA_0
            data[2]   // DATA_1
        };
        a2b_send_frame(node_addr, start_frame);

        uint8_t offset = 3;
        uint8_t counter = 1;
        while (offset < length) {
            uint8_t frame[4];
            frame[0] = FRAME_TYPE_CONT | (counter & 0x7F);
            frame[1] = (offset < length) ? data[offset++] : 0;
            frame[2] = (offset < length) ? data[offset++] : 0;
            frame[3] = (offset < length) ? data[offset++] : 0;
            a2b_send_frame(node_addr, frame);
            counter++;
        }
    }
}

uint8_t a2b_read_mailbox(uint8_t node_addr, uint8_t* buffer, uint8_t* length) {
    uint8_t frame[4];
    if (!a2b_receive_frame(frame))
        return 0;

    uint8_t frame_type = frame[0] & 0x80;
    if (frame_type == FRAME_TYPE_START) {
        uint8_t data_size = frame[0] & 0x7F;
        buffer[0] = frame[1];  // CID
        buffer[1] = frame[2];  // DATA_0
        buffer[2] = frame[3];  // DATA_1

        uint8_t offset = 3;
        uint8_t expected_counter = 1;

        while (offset < data_size) {
            if (!a2b_receive_frame(frame))
                return 0;

            if ((frame[0] & 0x7F) != expected_counter++)
                return 0;  // 순서 오류

            buffer[offset++] = frame[1];
            if (offset < data_size) buffer[offset++] = frame[2];
            if (offset < data_size) buffer[offset++] = frame[3];
        }

        *length = data_size;
        return 1;
    }
    return 0;  // Start Frame 아님
}
