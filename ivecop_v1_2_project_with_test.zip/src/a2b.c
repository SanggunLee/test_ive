#include "a2b.h"

// 실제 하드웨어에서는 SPI로 처리하겠지만, 여기서는 간단히 흉내만 낸다

void a2b_init(void) {
    // SPI, Mailbox 등 초기화
}

uint8_t a2b_discover_nodes(void) {
    // A2B 노드 탐색 로직 (여기선 항상 성공한다고 가정)
    return 1;
}

void a2b_reset(void) {
    // A2B 리셋 시퀀스
}

uint8_t a2b_receive_frame(uint8_t* frame) {
    // Mailbox 수신 처리 (여기선 예시로 가짜 프레임 생성)
    frame[0] = 0x02;
    frame[1] = 0x01;
    frame[2] = 0x10;
    frame[3] = 0x20;
    return 1;
}

void a2b_send_frame(uint8_t uid, const uint8_t* frame) {
    // SPI를 통해 Mailbox에 프레임 전송
}
