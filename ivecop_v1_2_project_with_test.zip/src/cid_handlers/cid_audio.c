#include <stdint.h>
#include "ivecop.h"

// Play Status (CID 0x20)
void cid_audio_play_status(uint8_t src_uid, uint8_t command) {
    // 실제 오디오 플레이/정지 로직
    // command: 0=Play, 1=Pause, 3=Track Forward, 4=Track Backward
    uint8_t response[3] = {0x20, 0x00, command};
    ivecop_send_command(src_uid, 0x01, response, 3);
}
