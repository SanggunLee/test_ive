#include <stdint.h>
#include "ivecop.h"

// Network startup/validation (CID 0x00)
void cid_network_startup(uint8_t src_uid) {
    // 예시: UID를 응답
    uint8_t response[3] = {0x00, 0x00, src_uid};
    ivecop_send_command(src_uid, 0x01, response, 3); // CID 01h 응답
}
