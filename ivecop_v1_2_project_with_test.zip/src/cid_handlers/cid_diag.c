#include <stdint.h>
#include "ivecop.h"

// Diagnostics 예시 처리 (CID 0xA0)
void cid_report_input_voltage(uint8_t src_uid, uint16_t millivolt) {
    uint8_t data[3] = {0xA0, (uint8_t)(millivolt >> 8), (uint8_t)(millivolt & 0xFF)};
    ivecop_send_command(src_uid, 0x01, data, 3);
}
