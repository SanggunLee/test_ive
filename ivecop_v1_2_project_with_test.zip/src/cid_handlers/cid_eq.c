#include <stdint.h>
#include "ivecop.h"

// Equalizer Bass 조절 (CID 0x33)
void cid_eq_bass_control(uint8_t src_uid, uint8_t zone, int8_t value) {
    // value 범위: -124% ~ +124%
    uint8_t response[3] = {0x33, 0x00, value};
    ivecop_send_command(src_uid, 0x01, response, 3);
}
