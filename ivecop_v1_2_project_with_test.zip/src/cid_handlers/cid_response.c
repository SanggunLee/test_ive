#include <stdint.h>

// Response Command 처리 (CID 0x01)는 일반적으로 IVECOP 상태 확인용이므로
// 별도 동작은 생략 가능. 필요한 경우 로깅 등에 사용.
void cid_handle_response(uint8_t* data, uint8_t len) {
    // 예: 상태 로깅
}
