#ifndef TIMER_UTILS_H
#define TIMER_UTILS_H

#include <stdint.h>

void timer_start(uint16_t ms);
uint8_t timer_expired(void);

#endif // TIMER_UTILS_H
