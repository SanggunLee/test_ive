#ifndef A2B_MAILBOX_H
#define A2B_MAILBOX_H

#include <stdint.h>

#define MAX_MAILBOX_SIZE 64  // 최대 수신 메시지 길이

// Mailbox 쓰기: data는 전송할 payload, length는 payload 길이
void a2b_write_mailbox(uint8_t node_addr, const uint8_t* data, uint8_t length);

// Mailbox 읽기: 읽은 payload를 buffer에 저장하고 실제 길이를 length에 반환
uint8_t a2b_read_mailbox(uint8_t node_addr, uint8_t* buffer, uint8_t* length);

#endif // A2B_MAILBOX_H
