#ifndef CRC_UTILS_H
#define CRC_UTILS_H

#include <stdint.h>

// 16-bit CRC 계산 (단순 예시 - 실제 AD2433 CRC 알고리즘은 다를 수 있음)
uint16_t calculate_crc16(const uint8_t* data, uint16_t length);

#endif // CRC_UTILS_H
