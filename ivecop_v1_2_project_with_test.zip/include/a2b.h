#ifndef A2B_H
#define A2B_H

#include <stdint.h>

void a2b_init(void);
uint8_t a2b_discover_nodes(void);
void a2b_reset(void);
uint8_t a2b_receive_frame(uint8_t* frame);
void a2b_send_frame(uint8_t uid, const uint8_t* frame);

#endif // A2B_H
