#ifndef IVECOP_H
#define IVECOP_H

void ivecop_init(void);
void ivecop_process(void);
void ivecop_handle_messages(void);
void ivecop_send_command(uint8_t uid, uint8_t cid, const uint8_t* data, uint8_t data_len);

#endif // IVECOP_H
